<?php $__env->startSection('content'); ?>
    <div class="row grid-responsive">
        <div class="column ">
            <div class="card">
                <div class="card-title">
                    <h3>Tambah Data Satuan</h3>
                </div>
                <div class="card-block">
                    <form class="form-horizontal" action="<?php echo e(route('satuan.update',$satuan->id_satuan)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?> <?php echo e(method_field('PATCH')); ?>

                        <div class="form-group">
                            <label for="nama_satuan" class="col-sm-2 control-label">Nama Satuan</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="nama_satuan" id="nama_satuan" value="<?php echo e($satuan->nama_satuan); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="button">SIMPAN PERUBAHAN</button>
                                <a href="<?php echo e(route('satuan.index')); ?>" class="button button-outline">BATAL</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>