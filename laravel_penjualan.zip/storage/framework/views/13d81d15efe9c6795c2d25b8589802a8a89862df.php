<?php $__env->startSection('content'); ?>
    <div class="row grid-responsive">
        <div class="column ">
            <div class="card">
                <div class="card-title">
                    <h3>
                        Data User
                        <div class="pull-right">
                            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary"><em class="fa fa-plus"></em> TAMBAH</a>
                        </div>
                    </h3>
                </div>
                <div class="card-block">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama User</th>
                                <th>Email</th>
                                <th>Level</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                             <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php if($user->level == 1): ?> Administrator <?php else: ?> User <?php endif; ?></td>
                                <td>
                                    <a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-xs btn-warning"><em class="fa fa-edit"></em> ubah</a>
                                    <a onclick ="event.preventDefault(); document.getElementById('deleteID<?php echo e($user->id); ?>').submit();" title="ubah" href="<?php echo e(route('user.destroy',$user->id)); ?>" class="btn btn-xs btn-danger"><em class="fa fa-trash"></em> hapus</a>
                                    <form id="deleteID<?php echo e($user->id); ?>" action="<?php echo e(route('user.destroy',$user->id)); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?>

                                    </form>
                                </td>
                            </tr>
                            <?php echo $__env->make('admin.user.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.table').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>