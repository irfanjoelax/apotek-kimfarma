<!DOCTYPE html>
<html>
<head>
	<title>Apotek KIM FARMA</title>
</head>
<body>
<center>
	<h2>Apotek KIM FARMA</h2>
</center>
<hr>
<table width="100%" border="0.5">
	<tr>
		<td>No Batch</td>
		<td>Nama Barang</td>
		<td>Satuan</td>
		<td>Diskon</td>
		<td>Harga Beli</td>
		<td>Harga Jual</td>
		<td>Harga Resep</td>
		<td>Stok</td>
	</tr>
	<?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($barang->no_batch); ?></td>
		<td><?php echo e($barang->nama_barang); ?></td>
		<td><?php echo e($barang->nama_satuan); ?></td>
		<td align="right"><?php echo e($barang->diskon." %"); ?></td>
		<td align="right">Rp. <?php echo e(format_uang($barang->harga_beli)); ?></td>
		<td align="right">Rp. <?php echo e(format_uang($barang->harga_jual)); ?></td>
		<td align="right">Rp. <?php echo e(format_uang($barang->harga_resep)); ?></td>
		<td align="right"><?php echo e($barang->stok); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>