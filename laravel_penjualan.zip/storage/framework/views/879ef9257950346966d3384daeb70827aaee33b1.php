<?php $__env->startSection('content'); ?>
  <div class="row grid-responsive">
        <div class="column ">
            <div class="card">
                <div class="card-title">
                    <h3>
                      Data Detail Penjualan
                      <div class="pull-right">
                        <a href="<?php echo e(route('penjualan.index')); ?>" class="btn btn-warning"><em class="fa fa-arrow-left"></em> KEMBALI</a>
                      </div>
                    </h3>
                </div>
                <div class="card-block">
                    <table class="table table-bordered" id="table-penjualan">
                        <thead>
                          <tr>
                            <th>No.</th>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                          </tr>
                          <tbody>
                            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($no++); ?></td>
                              <td><?php echo e($detail->kode_barang); ?></td>
                              <td><?php echo e($detail->nama_barang); ?></td>
                              <td><?php echo e($detail->jumlah); ?></td>
                              <td><?php echo e("Rp. ".format_uang($detail->subtotal)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>