<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Laporan Penjualan dan Pendapatan</title>

	<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
	
</head>
<body>
	<h3 class="text-center">Laporan Total Pendapatan</h3>
	<h4 class="text-center">Tanggal <?php echo e(tanggal_indonesia($tanggal_awal)); ?> s/d <?php echo e(tanggal_indonesia($tanggal_akhir)); ?></h4>

	<hr>

	<table class="table table-striped table-bordered">
		<thead>
			<tr>
				<th>No.</th>
				<th>Tanggal</th>
				<th>Penjualan</th>
				<th>Pengeluaran</th>
				<th>Pendapatan</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
			<tr>
				<?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<td><?php echo e($col); ?></td>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</body>
</html>