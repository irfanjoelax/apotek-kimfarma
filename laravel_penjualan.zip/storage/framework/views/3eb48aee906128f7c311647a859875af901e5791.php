<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Apotek Kim Farma</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Template Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('medialoot/css/font-awesome.min.css')); ?>">
    
    <!-- CSS Reset -->
    <link rel="stylesheet" href="<?php echo e(asset('medialoot/css/normalize.css')); ?>">
    
    <!-- Milligram CSS minified -->
    <link rel="stylesheet" href="<?php echo e(asset('medialoot/css/milligram.min.cs')); ?>s">
    
    <!-- Main Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('medialoot/css/styles.css')); ?>">

    <!-- dataTables Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('datatables/jquery.dataTables.css')); ?>">


</head>
<body>
    
    <?php echo $__env->make('layouts.partials._navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <div class="row">
        
        <?php echo $__env->make('layouts.partials._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <section id="main-content" class="column column-offset-20">
            <?php echo $__env->make('layouts.partials._alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('layouts.partials._logout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </section>
        
    </div>


    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('medialoot/js/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('medialoot/js/chart-data.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
