<?php $__env->startSection('content'); ?>
    <div class="row grid-responsive">
        <div class="column ">
            <div class="card">
                <div class="card-title">
                    <h3>
                        Data Barang
                        <div class="pull-right">
                            <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-primary">TAMBAH</a>
                            <a href="<?php echo e(route('barang.excel.view')); ?>" class="btn btn-success">EXPORT/IMPORT EXCEL</a>
                            <a href="<?php echo e(route('barang.pdf')); ?>" class="btn btn-danger">IMPORT PDF</a>
                            
                        </div>
                    </h3>
                </div>
                <div class="card-block">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No Batch</th>
                                <th>Nama Barang</th>
                                <th>Satuan</th>
                                <th>Diskon</th>
                                <th>Harga Beli</th>
                                <th>Harga Jual</th>
                                <th>Harga Resep</th>
                                <th>Stok</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/print.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            // load DataTable
            $('.table').DataTable({
                "processing": true,
                "serverside": true,
                "ajax": {
                    "url": "<?php echo e(route('barang.data')); ?>",
                    "type": "GET",
                }
            });

            // script untuk import data ke pdf
            $('#btnImportPdf').click(function() {
                $.ajax({
                    url: '<?php echo e(route('barang.pdf')); ?>',
                    type: 'GET',
                    success: function(data){
                        $('#btnImportPdf').text('IMPORTING FILE...');
                    }
                })
            });
        });

        // function untuk menghapus data
        function deleteData(id){
            if (confirm("Apakah Yakin Ingin Menghapus Data Ini ?")) {
                $.ajax({
                    url: "barang/" +id,
                    type: "POST",
                    data: {
                        '_method': 'DELETE',
                        '_token': $('meta[name=csrf-token]').attr('content'),
                    },
                    success: function(data){
                        $('.table').DataTable().ajax.reload();
                    },
                    error: function(data){
                        console.log(data);
                    }
                });
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>