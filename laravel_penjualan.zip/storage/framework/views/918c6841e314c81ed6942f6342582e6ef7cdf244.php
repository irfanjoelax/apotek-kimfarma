<?php $__env->startSection('content'); ?>
    <div class="row grid-responsive">
        <div class="column ">
            <div class="card">
                <div class="card-title">
                    <h3>
                        Data Supplier
                        <div class="pull-right">
                            <a href="<?php echo e(route('supplier.create')); ?>" class="btn btn-primary"><em class="fa fa-plus"></em> TAMBAH</a>
                        </div>
                    </h3>
                </div>
                <div class="card-block">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Supplier</th>
                                <th>Alamat</th>
                                <th>Telepon</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($supplier->nama_supplier); ?></td>
                                <td><?php echo e($supplier->alamat); ?></td>
                                <td><?php echo e($supplier->telepon); ?></td>
                                <td>
                                    <a href="<?php echo e(route('supplier.edit',$supplier->id_supplier)); ?>" class="btn btn-xs btn-warning"><em class="fa fa-edit"></em> ubah</a>
                                    <a onclick ="event.preventDefault(); document.getElementById('deleteID<?php echo e($supplier->id_supplier); ?>').submit();" title="ubah" href="<?php echo e(route('supplier.destroy',$supplier->id_supplier)); ?>" class="btn btn-xs btn-danger"><em class="fa fa-trash"></em> hapus</a>
                                    <form id="deleteID<?php echo e($supplier->id_supplier); ?>" action="<?php echo e(route('supplier.destroy',$supplier->id_supplier)); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?>

                                    </form>
                                </td>
                            </tr>
                            <?php echo $__env->make('admin.supplier.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.table').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>