<form action="<?php echo e(route('pembelian.destroy', $pembelian->id_pembelian)); ?>" method="POST">
  <?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?>

  <div class="modal fade" id="<?php echo e($pembelian->id_pembelian); ?>modalDelete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Konfirmasi Hapus Data</h4>
      </div>
      <div class="modal-body">
        <strong>Apakah Anda Yakin Ingin Menghapus data ini </strong>
        <ul>
          <li><?php echo e(tanggal_indonesia($pembelian->tanggal, false)); ?></li>
          <li><?php echo e($pembelian->nama_supplier); ?></li>
        </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">TUTUP</button>
        <button type="submit" class="btn btn-danger">HAPUS</button>
      </div>
    </div>
  </div>
</div>
</form>