<form action="<?php echo e(route('pengeluaran.destroy', $pengeluaran->id_pengeluaran)); ?>" method="POST">
  <?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?>

  <div class="modal fade" id="<?php echo e($pengeluaran->id_pengeluaran); ?>modalDelete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Konfirmasi Hapus Data</h4>
      </div>
      <div class="modal-body">
        <strong>Apakah Anda Yakin Ingin Menghapus data ini <h3><?php echo e($pengeluaran->jenis_pengeluaran); ?> ?</h3> </strong>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger"><em class="fa fa-check"></em> HAPUS</button>
        <button type="button" class="btn btn-warning" data-dismiss="modal"><em class="fa fa-remove"></em> TUTUP</button>
      </div>
    </div>
  </div>
</div>
</form>