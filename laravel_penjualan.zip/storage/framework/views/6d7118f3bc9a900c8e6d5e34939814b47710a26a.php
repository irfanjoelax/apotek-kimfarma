<?php if(session('info')): ?>
<div class="alert background-success"><em class="fa fa-thumbs-up"></em> 
	<strong><?php echo e(session('info')); ?></strong>
</div>
<?php endif; ?>

<?php if(session('warning')): ?>
<div class="alert background-warning"><em class="fa fa-warning"></em> 
	<strong><?php echo e(session('warning')); ?></strong>
</div>
<?php endif; ?>

<?php if(session('danger')): ?>
<div class="alert background-danger"><em class="fa fa-times-circle"></em> 
	<strong><?php echo e(session('danger')); ?></strong>
</div>
<?php endif; ?>